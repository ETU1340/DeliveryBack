import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';
import { MANAGER, CLIENT, LIVREUR } from '../services/roleService';

const options = { discriminatorKey: 'role', collection: 'users' };

const UserSchema = new mongoose.Schema({
  email: { type: String, required: true, unique: true },
  userName: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  name: { type: String, required: true },
  image: { type: String, required: true },
  firstName: { type: String, required: true },
  address: { type: String, required: true },
  phone: { type: String, required: true },
  role: { type: String, required: true, enum: [MANAGER, CLIENT, LIVREUR] },
}, options);

// Hash the password before saving the user.
UserSchema.pre('save', async function(next) {
  if (!this.isModified('password')) return next();
  const salt = await bcrypt.genSalt(10);
  this.password = await bcrypt.hash(this.password, salt);
  next();
});

const User = mongoose.model('User', UserSchema);
export default User;
